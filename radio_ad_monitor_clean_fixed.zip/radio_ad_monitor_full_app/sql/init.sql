create table if not exists settings (
  id serial primary key,
  report_email text not null default 'moranmano@gmail.com',
  stream_url text not null default 'https://cdna.streamgates.net/TheBest/live/icecast.audio',
  stream_backup_urls text,
  match_threshold double precision not null default 0.78,
  dedup_minutes integer not null default 8,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into settings (id, report_email, stream_url, stream_backup_urls)
values (
  1,
  'moranmano@gmail.com',
  'https://cdna.streamgates.net/TheBest/live/icecast.audio',
  'http://radio.96fm.co.il/96fm,http://96.cdnwz.net/96fm,http://radio.streamgates.net/stream/KOLREGA'
)
on conflict (id) do nothing;

create table if not exists ads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  original_filename text not null,
  storage_path text not null,
  duration_seconds double precision,
  is_active boolean not null default true,
  fingerprint_version integer not null default 1,
  fingerprint_json jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_ads_active on ads(is_active);

create table if not exists detections (
  id uuid primary key default gen_random_uuid(),
  ad_id uuid not null references ads(id) on delete cascade,
  ad_name_snapshot text not null,
  detected_at timestamptz not null,
  confidence double precision not null,
  evidence_storage_path text,
  evidence_public_url text,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_detections_detected_at on detections(detected_at desc);
create index if not exists idx_detections_ad_id on detections(ad_id);

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

DROP TRIGGER IF EXISTS trg_settings_updated_at ON settings;
create trigger trg_settings_updated_at
before update on settings
for each row execute function set_updated_at();

DROP TRIGGER IF EXISTS trg_ads_updated_at ON ads;
create trigger trg_ads_updated_at
before update on ads
for each row execute function set_updated_at();
